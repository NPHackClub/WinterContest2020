import discord
import random
from keep_alive import keep_alive

keep_alive()
# the array that a joke is chosen from 
jokes = ['Why did the chicken cross the road: ||To get to the other side||','Whats the best thing about switzerland: ||i dont know but the flag is a big plus||', 'Why was 6 afrad of 7: || because 7 8 9||','Why did the gym close down: ||it just didnt work out||','What do you call fake spaghetti: ||an impasta||','Why did the turkey cross the road twice: ||to prove he wasnt a chicken||','What did the fisherman say to the magician: ||pick a cod any cod||','Why did the m&m go to school: ||it wanted to be a smartie||','what do you call a sleeping bull: ||a bull dozer||','why dont cannibals eat clowns: ||they taste funny||','Why do bees have sticky hair: ||because they use honey combs||','i asked my dog whats 2-2: ||he said nothing||','Why do golfers wear two pairs of pants: ||incase they get a hole in one||','why did the banana go to the doctor: ||it didnt peel well||','Why do we tell actors to break a leg: ||because every play has a cast||','did you hear about the actor who fell through the floorboards: ||its ok he was going through a stage||','did you hear about the claustrophobic astonaut: ||he just needed some space||','why cant you trust an atom: ||they make up everything||','Where are average things manufactured: ||the satisfactory||','What do you call a parade of rabits hopping backwards: ||a receding hairline||','what rhymes with orange: ||no it doesnt||','Where do you find a cow with no legs: ||Right where you left it||','Why arent koalas actual bears: ||They dont meet the koalafications||','What do Alexander the Great and Winnie the Pooh have in common: ||Same middle name||','What did the left eye say to the right eye: ||Between you and me, something smells||','Why is England the wettest country: ||Because the queen has reigned there for years||','Whats a foot long and slippery: ||A slipper||']



client = discord.Client()
# alerts when bot goes online
@client.event
async def on_ready():
    print('We have logged in as {0.user}'.format(client))
# detects if the command is called

@client.event
async def on_message(message):
    if message.author == client.user:
        return
# runs command
    if message.content.startswith('!joke'):
        await message.channel.send(random.choice(jokes))

client.run('Nzg4MTA3NjMyMzA0OTc5OTc5.X9esbQ.lywyVKTKaBxsi-dghSbEllPYfX4')